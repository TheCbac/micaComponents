/***************************************************************************
*                                       MICA
* File: Sflash.c
* Workspace: micaCompnents
* Project Name: libMica
* Version: v1.0
* Author: Craig Cheney
*
* Brief:
*   API for interacting with the Supervisory flash
* 
* Authors:
*   Craig Cheney
*
* Change Log:
*   2018.03.03 CC - Document created
********************************************************************************/
#include "`$INSTANCE_NAME`.h"

/*******************************************************************************
* Function Name: `$INSTANCE_NAME`_WriteRow()
****************************************************************************//**
*
* \brief Copies the data in 'rowData' and writes it into the Supervisory Flash 
*   (SFlash) section of code. Wrapper of the Cypress function CySysSFlashWriteUserRow
*
* \param rowNum
*   The row number of the SFlash to write to. 
*   
* \param rowData
*   Buffer copy data from
*
*\return 
* uint32: An error code with the result of the Write procedure. 
* The possible error codes are:
*
*  Errors codes                             | Description
*   ------------                            | -----------
*   ERR_NO_ERROR                            | Read was successful
*   ERR_SFLASH_WRITE_FAILED                 | Write failed - actually masking real error
*
*******************************************************************************/
uint32 `$INSTANCE_NAME`_WriteRow(uint8 rowNum, const uint8* rowData){
    /* Write the data and return the result */
    return CySysSFlashWriteUserRow(rowNum, rowData);
}
/* [] END OF FILE */
