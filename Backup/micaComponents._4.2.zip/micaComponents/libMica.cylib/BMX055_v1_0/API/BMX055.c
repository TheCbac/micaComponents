/***************************************************************************
*                                       MICA
* File: BMX055.c
* Workspace: micaComponents
* Project Name: libMica
* Version: v1.0
* Author: Craig Cheney
*
* Brief:
*   API for interacting with the Bosch BMX055 IMU
* 
* Authors:
*   Craig Cheney
*
* Change Log:
*   2018.03.13 CC - Document created
********************************************************************************/
#include "`$INSTANCE_NAME`.h"
#include "`$i2cIncludeFile`.h"
#include "micaCommon.h"

/*******************************************************************************
* Function Name: `$INSTANCE_NAME`_AccStart()
********************************************************************************
*
* \brief Starts the accelerometer, loads all parameters 
*
* \param deviceAddr
*  Address of the device
*
* \param numParams
* Number of parameters to be written to the device. The array sensor params
* should be double this length as each parameter is in the formate (address, value)
* 
* \param sensorParams
* An array containing the parameters. (address, value) 
*
* \return
* uint8: An error code with the result of the start procedure. 
* The possible error codes are:
*
*  Errors codes                             | Description
*   ------------                            | -----------
*   ERR_NO_ERROR                            | On successful operation
*   Error from I2C Write function, `$i2cWriteFunction`
*******************************************************************************/
uint32 `$INSTANCE_NAME`_SetParameters(uint8 deviceAddr, uint8 numParams, uint8* sensorParams) {
    /* Declare local variables */
    uint8 index;
    /* Ensure the correct device was written to */
    switch(deviceAddr){
        /* Accelerometer, gyroscope or magnetometer */
        case `$INSTANCE_NAME`_ACC_ADDR:        
        case `$INSTANCE_NAME`_GYR_ADDR:
        case `$INSTANCE_NAME`_MAG_ADDR:
            break;
        /* Unknown device */
        default:
            return `$INSTANCE_NAME`_ERR_DEVICE_UNKNOWN;
    }
   /* Iterate through each command */
   for (index = ZERO; index < (numParams * `$INSTANCE_NAME`_PARAM_BYTE_LEN ); index += `$INSTANCE_NAME`_PARAM_BYTE_LEN ){
    //    micaI2C_writeReg(BMX_ACC_ADDR, sensorParams[index], sensorParams[index+ONE]);
        uint32 result = `$i2cWriteFunction`(deviceAddr, sensorParams[index], sensorParams[index+ONE]);
        /* Ensure it was valid */
        if (result != `$INSTANCE_NAME`_ERR_OK) {
            return result;
        }
   }
    /* Return Success*/
    return `$INSTANCE_NAME`_ERR_OK;
}


/*******************************************************************************
* Function Name: `$INSTANCE_NAME`_Acc_Read()
****************************************************************************//**
*
* \brief
*  Reads the accelerometer based on the present channels. Return the data
*  and the number of channels sampled. 
*
* \param dataArray
*  Array to place the data into
*       
* \param sensorChannels 
* A bit mask of the channels to sample 
*
* \return  **** PICK UP HERE *****
* uin32: An error code with the result of the start procedure. 
* The possible error codes are:
*
*  Errors codes                             | Description
*   ------------                            | -----------
*   ERR_NO_ERROR                            | On successful operation
*   ERR_NO_CHANNELS                         | Data was not requested from any channels
*
*******************************************************************************/
uint32 `$INSTANCE_NAME`_Acc_Read(uint16* dataArray, uint8 sensorChannels){
   /* Read in the accelerometer data */
   uint8 msb, lsb;
   uint16 channelCount = INDEX_ZERO;
   /* X Data */
   if (sensorChannels & MICA_CHANNEL_MASK_X){
       channelCount++;
       /* Read LSB first to lock MSB */
       lsb = micaI2C_readReg(BMX_ACC_ADDR, BMX_ACC_X_LSB);
       msb = micaI2C_readReg(BMX_ACC_ADDR, BMX_ACC_X_MSB);
       /* Discard LS nibble */
       dataArray[channelCount] = (msb << SHIFT_BYTE_HALF) | ((lsb >> SHIFT_BYTE_HALF) & MASK_LOW_NIBBLE);
   }
   /* Y Data */
   if (sensorChannels & MICA_CHANNEL_MASK_Y){ 
       channelCount++;
       lsb = micaI2C_readReg(BMX_ACC_ADDR, BMX_ACC_Y_LSB);
       msb = micaI2C_readReg(BMX_ACC_ADDR, BMX_ACC_Y_MSB);
       dataArray[channelCount] = (msb << SHIFT_BYTE_HALF) | ((lsb >> SHIFT_BYTE_HALF) & MASK_LOW_NIBBLE);
   }
   /* Z Data */
   if (sensorChannels & MICA_CHANNEL_MASK_Z){
       channelCount++;
       lsb = micaI2C_readReg(BMX_ACC_ADDR, BMX_ACC_Z_LSB);
       msb = micaI2C_readReg(BMX_ACC_ADDR, BMX_ACC_Z_MSB);
       dataArray[channelCount] = (msb << SHIFT_BYTE_HALF) | ((lsb >> SHIFT_BYTE_HALF) & MASK_LOW_NIBBLE);
   }
   /* if no channels reported, return noData */
   if(!channelCount){return ERR_NO_CHANNELS;}
   /* Pack the Channel info */
   dataArray[MICA_CHANNEL_INDEX_NUM_CHAN] = channelCount;
   /* Return success */
    return ERR_NO_ERROR;
    
}

/* [] END OF FILE */
